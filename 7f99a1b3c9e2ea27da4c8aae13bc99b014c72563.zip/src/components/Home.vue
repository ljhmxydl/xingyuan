<template>
  <div>
    <div class="jumbotron">
      <h1 class="display-3 text-success">简 读</h1>
      <br>
      <p class="lead">微信公众号简单阅读器 RSS v0.70</p>
      <hr class="my-2">
      <p>公众号平常是在微信里阅读，经常会给微信消息打断。这里是一个不被打扰、能个人定制的安静阅读环境。</p>
      <p>搜索 -> 订阅，两步就OK了！</p>
      <p class="lead">
        <router-link to="/search" class="btn btn-outline-success btn-lg" href="#" role="button">
          我要体验 <i class="fa fa-plus-circle"></i></router-link>
      </p>
    </div>
<p>2017-1-25 Note: Bootstrap v4 Alpha6 just released, need to re-write the UI </p>
  </div>
</template>

<script>

</script>